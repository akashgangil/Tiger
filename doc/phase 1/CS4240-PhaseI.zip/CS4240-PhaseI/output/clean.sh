#!/bin/bash

rm *.png
rm *.dot
rm -R classes
